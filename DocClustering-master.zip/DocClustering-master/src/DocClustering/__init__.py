from DocClustering import dclustering as dclustering

__version__= "0.1.0-dev"


__title__ = 'DocClustering'
__name__ = 'DocClustering'
__description__ = ''
__url__ = ''

__author__ = ''
__email__ = ''

__license__ = ''
__copyright__ = ''

